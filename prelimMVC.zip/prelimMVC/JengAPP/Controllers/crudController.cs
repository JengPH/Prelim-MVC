using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using JengAPP.Models;

namespace JengAPP.Controllers
{
    [Route("[controller]")]
    [Route("[controller]/[action]")]
    public class crudController : Controller
    {
         private readonly testContext _context;

        public crudController(testContext context)
        {
             _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
              return View(_context.Testusers.ToList());
        }
        
        public IActionResult Create()
        {
            return View();
        }
        
           public IActionResult Update(int ID)
        {
            var ts = _context.Testusers.Where(q => q.Id== ID).FirstOrDefault();
            return View(ts);
        }

        public IActionResult Delete(int ID)
        {
            var testuserDelete = _context.Testusers.Where(q => q.Id == ID).FirstOrDefault();
            _context.Testusers.Remove(testuserDelete);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

         [HttpPost]
        public IActionResult Create(Testuser tstusr)
        {
            _context.Testusers.Add(tstusr);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

          [HttpPost]
        public IActionResult Update(Testuser testuser)
        {
            if(ModelState.IsValid)
            {
                _context.Testusers.Update(testuser);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }
            return View(testuser);
        }

      
    }
}