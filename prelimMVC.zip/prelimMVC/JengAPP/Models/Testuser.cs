﻿using System;
using System.Collections.Generic;

namespace JengAPP.Models
{
    public partial class Testuser
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Age { get; set; }
        public string Address { get; set; }
    }
}
