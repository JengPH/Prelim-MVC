﻿using System;
using System.Collections.Generic;

namespace JengAPP.Models
{
    public partial class Testuser
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
